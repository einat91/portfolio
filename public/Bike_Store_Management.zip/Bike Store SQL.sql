/* Bike Store */
/*****/

/* Customers */
    /* Total Customers */
SELECT
    count(customer_id) AS TotalCustomers
FROM
    BikeStores.sales.customers
    /* Customers by State */
SELECT
    state as State,
    COUNT(customer_id) AS CustomersNumber
FROM
    BikeStores.sales.customers
GROUP BY
    state
    /* Customers with No Phone Number */
SELECT
    COUNT(customer_id) AS NoPhone
FROM
    BikeStores.sales.customers
WHERE
    phone IS NULL
    /* Top 10 Customers by Orders */
SELECT
    TOP 10 customers.customer_id as CustomerID,
    COUNT(*) OrdersNumbers
FROM
    BikeStores.sales.customers
    LEFT JOIN BikeStores.sales.orders o ON customers.customer_id = o.customer_id
GROUP BY
    customers.customer_id
ORDER BY
    OrdersNumbers DESC

/* Staff     */
    /* Total Employees */
SELECT
    staffs.last_name + ' ' + staffs.first_name AS StaffName
FROM
    BikeStores.sales.staffs
SELECT
    SUM(staffs.staff_id) AS TotalStaff
FROM
    BikeStores.sales.staffs
    /* Employees by Store */
SELECT
    COUNT(staffs.staff_id) AS StaffsNumber,
    store_name AS StoreName
FROM
    BikeStores.sales.staffs
    INNER JOIN BikeStores.sales.stores ON BikeStores.sales.staffs.store_id = BikeStores.sales.stores.store_id
GROUP BY
    store_name
    /* Employees Who Start with A */
SELECT
    first_name AS NamesStartWithA
FROM
    BikeStores.sales.staffs
WHERE
    first_name LIKE 'A%'
    /* Employees with Z in Their Names */
SELECT
    first_name AS NamesWithZ
FROM
    BikeStores.sales.staffs
WHERE
    first_name LIKE '%Z%'
    /* Employees Who Don't End with F */
SELECT
    first_name AS NamesEndWithF
FROM
    BikeStores.sales.staffs
WHERE
    first_name LIKE '%F'
    /* The Longest Employee's Name */
SELECT
    TOP 1 LEN(first_name) AS LettersNumber,
    first_name AS FirstName
FROM
    BikeStores.sales.staffs
ORDER BY
    LettersNumber DESC
    
/* Stores */
    /* Stores' Full Address */
SELECT
    store_name + ' - ' + street + ' ' + city + ' ' + zip_code + ', ' + phone AS StoreDetails
FROM
    BikeStores.sales.stores
    /* Change to 'Dizzy's Bikes' Store Name */
SELECT
    'Dizzy''s' + ' ' + store_name AS StoreNewName
FROM
    BikeStores.sales.stores
    
/* Products */
    /* Total Products */
SELECT
    COUNT(product_id) AS TotalProducts
FROM
    BikeStores.production.products
    /* Products' Mean */
SELECT
    AVG(list_price) AS ProductsMean
FROM
    BikeStores.production.products
    /* Products' Median */
SELECT
    TOP 1 PERCENTILE_CONT(0.5) WITHIN GROUP (
        ORDER BY
            list_price DESC
    ) OVER (PARTITION BY 1) AS ProductsMedian
FROM
    BikeStores.production.products
    /* Products' Variance */
SELECT
    VARP(list_price) AS ProductsVariance
FROM
    BikeStores.production.products
    /* Products' Range */
SELECT
    MAX(list_price) - MIN(list_price) AS ProductsRange
FROM
    BikeStores.production.products
    /* The Most Popular Brand */
SELECT
    TOP 1 COUNT(products.brand_id) AS Numbers,
    brands.brand_name as MostCommonBrand
FROM
    BikeStores.production.products FULL
    OUTER JOIN BikeStores.production.brands ON BikeStores.production.brands.brand_id = BikeStores.production.products.brand_id
GROUP BY
    brands.brand_name
ORDER BY
    Numbers DESC
    /* The Most Popular Category */
SELECT
    TOP 1 COUNT(products.category_id) AS Numbers,
    categories.category_name as MostCommonCategory
FROM
    BikeStores.production.products FULL
    OUTER JOIN BikeStores.production.categories ON BikeStores.production.categories.category_id = BikeStores.production.products.category_id
GROUP BY
    categories.category_name
ORDER BY
    Numbers DESC
    /* The Most Expensive Product */
SELECT
    TOP 1 list_price AS HighestPrice,
    product_name as ProductName
FROM
    BikeStores.production.products
ORDER BY
    list_price DESC
    /* The Cheapest Product */
SELECT
    TOP 1 list_price AS LowestPrice,
    product_name as ProductName
FROM
    BikeStores.production.products
ORDER BY
    list_price ASC
    /* Model Year Range */
SELECT
    MAX(DISTINCT model_year) AS MaxYear,
    MIN(DISTINCT model_year) AS MinYear,
    MAX(DISTINCT model_year) - MIN(DISTINCT model_year) AS ModelYearRange
FROM
    BikeStores.production.products
    
/* Orders */
    /* The Last Order: Store, Date, Customer and Employee Details */
SELECT
    TOP 1 orders.order_date AS LatestOrderDate,
    staffs.first_name + ' ' + staffs.last_name AS StaffName,
    customers.first_name + ' ' + customers.last_name AS CustomerName,
    stores.store_name AS StoreName
FROM
    BikeStores.sales.orders
    INNER JOIN BikeStores.sales.staffs ON BikeStores.sales.orders.staff_id = BikeStores.sales.staffs.staff_id
    INNER JOIN BikeStores.sales.customers ON BikeStores.sales.orders.customer_id = BikeStores.sales.customers.customer_id
    INNER JOIN BikeStores.sales.stores ON BikeStores.sales.orders.store_id = BikeStores.sales.stores.store_id
ORDER BY
    orders.order_date DESC
    /* The Most Popular Store by Orders */
SELECT
    COUNT(orders.order_id) AS OrdersNumber,
    stores.store_name AS MaxOrdersStoreName
FROM
    BikeStores.sales.orders FULL
    OUTER JOIN BikeStores.sales.stores ON BikeStores.sales.orders.store_id = BikeStores.sales.stores.store_id
GROUP BY
    stores.store_name
ORDER BY
    stores.store_name ASC
    /* The Least Popular Product by Orders */
SELECT
    TOP 5 COUNT(order_items.product_id) AS OrdersNumber,
    products.product_name AS MinOrdersProductName
FROM
    BikeStores.sales.order_items FULL
    OUTER JOIN BikeStores.sales.orders ON BikeStores.sales.orders.order_id = BikeStores.sales.order_items.order_id FULL
    OUTER JOIN BikeStores.production.products ON BikeStores.sales.order_items.product_id = BikeStores.production.products.product_id
GROUP BY
    products.product_name
HAVING
    COUNT(order_items.product_id) != 0
ORDER BY
    COUNT(order_items.product_id) ASC
    /* Top 10 Best Sellers by Store */
SELECT
    TOP 10 COUNT(order_items.product_id) AS OrdersNumber,
    products.product_name AS BestSellers
FROM
    BikeStores.sales.order_items FULL
    OUTER JOIN BikeStores.sales.orders ON BikeStores.sales.orders.order_id = BikeStores.sales.order_items.order_id FULL
    OUTER JOIN BikeStores.production.products ON BikeStores.sales.order_items.product_id = BikeStores.production.products.product_id
GROUP BY
    products.product_name
HAVING
    COUNT(order_items.product_id) != 0
ORDER BY
    COUNT(order_items.product_id) DESC
    /* Top Customers By Orders Number */
SELECT
    TOP 1 COUNT(orders.customer_id) AS TopOrdersNumber,
    customers.first_name + ' ' + customers.last_name as TopCustomer
FROM
    BikeStores.sales.orders
    INNER JOIN BikeStores.sales.order_items ON BikeStores.sales.orders.order_id = BikeStores.sales.order_items.order_id
    INNER JOIN BikeStores.sales.customers ON BikeStores.sales.orders.order_id = BikeStores.sales.customers.customer_id
GROUP BY
    customers.first_name + ' ' + customers.last_name
ORDER BY
    COUNT(orders.customer_id) DESC
    /* Top Employee by Orders Number */
SELECT
    COUNT(orders.staff_id) AS TotalOrders,
    staffs.first_name + ' ' + staffs.last_name as TopStaffMember
FROM
    BikeStores.sales.orders
    INNER JOIN BikeStores.sales.staffs ON BikeStores.sales.orders.staff_id = BikeStores.sales.staffs.staff_id
GROUP BY
    staffs.first_name + ' ' + staffs.last_name
ORDER BY
    COUNT(orders.staff_id) DESC
    /* Top Customers Who Order by the Top Employee */
SELECT
    TOP 5 COUNT(orders.customer_id) AS TotalOrders,
    customers.first_name + ' ' + customers.last_name AS CustomerName
FROM
    BikeStores.sales.orders
    INNER JOIN BikeStores.sales.customers ON BikeStores.sales.customers.customer_id = BikeStores.sales.orders.customer_id
WHERE
    orders.staff_id = 9
GROUP BY
    customers.first_name + ' ' + customers.last_name
ORDER BY
    COUNT(orders.customer_id) DESC
    /* The Most Profitable Month */
SELECT
    TOP 1 DATENAME(month, order_date) AS MostProfitableMonth
FROM
    BikeStores.sales.orders
GROUP BY
    DATENAME(month, order_date)
ORDER BY
    COUNT(orders.order_id) DESC
    /* Discount Column, Total 'Losses' for Discounts */
SELECT
    order_items.order_id AS OrderID,
    order_items.list_price AS OriginalPrice,
    order_items.list_price - order_items.list_price * discount AS DiscountedPrice,
    product_name as ProductName
FROM
    BikeStores.sales.order_items
    INNER JOIN BikeStores.production.products ON BikeStores.production.products.product_id = BikeStores.sales.order_items.product_id
ORDER BY
    order_items.order_id
SELECT
    COUNT(list_price) AS TotalProductSold,
    SUM(list_price) as TotalOriginal,
    SUM(list_price - order_items.list_price * discount) AS TotalDiscount,
    SUM(list_price) - SUM(list_price -(order_items.list_price * discount)) AS TotalLoss
FROM
    BikeStores.sales.order_items
    /* Top Employee by Discounts Average */
SELECT
    TOP 3 AVG(order_items.discount) AS AverageDiscount,
    staff_id as StaffID
FROM
    BikeStores.sales.order_items FULL
    OUTER JOIN BikeStores.sales.orders ON BikeStores.sales.orders.order_id = BikeStores.sales.order_items.order_id
GROUP BY
    orders.staff_id
ORDER BY
    AVG(order_items.discount) DESC
SELECT
    staffs.first_name + ' ' + staffs.last_name AS TopStaffMember
FROM
    BikeStores.sales.staffs
WHERE
    staff_id = 6
    /* Total Orders From 31.01.16-18.02.16 */
SELECT
    COUNT(order_id) AS TotalOrdersJanFeb
FROM
    BikeStores.sales.orders
WHERE
    order_date BETWEEN '2016-01-31'
    AND '2016-02-18'
    /* Orders From 31.01.16-18.02.16 By Store */
SELECT
    COUNT(order_id) AS TotalOrdersJanFeb,
    store_id AS StoreID
FROM
    BikeStores.sales.orders
WHERE
    order_date BETWEEN '2016-01-31'
    AND '2016-02-18'
GROUP BY
    store_id

/* Stocks */
    /* Out of Stock Products */
SELECT
    stocks.product_id AS ProductID,
    products.product_name AS ProductName,
    stocks.quantity AS Quantity
FROM
    BikeStores.production.stocks
    INNER JOIN BikeStores.production.products ON products.product_id = stocks.product_id
WHERE
    quantity = 0
ORDER BY
    stocks.product_id ASC
    /* The Store with the Highest Number of Out-of-Stock Products */
SELECT
    COUNT(stocks.product_id) AS ProductID,
    stores.store_name AS StoreName
FROM
    BikeStores.production.stocks FULL
    OUTER JOIN BikeStores.sales.stores ON BikeStores.sales.stores.store_id = BikeStores.production.stocks.store_id
WHERE
    quantity = 0
GROUP BY
    stores.store_name
ORDER BY
    COUNT(stocks.product_id) DESC
    /* The Most In-Stock Product */
SELECT
    TOP 3 stocks.quantity AS Quantity,
    stocks.product_id AS ProductID,
    products.product_name as ProductName
FROM
    BikeStores.production.stocks
    INNER JOIN BikeStores.production.products ON products.product_id = stocks.product_id
ORDER BY
    stocks.quantity DESC
    
/* Mixed Tables */
    /* Price Raise in 5% */
SELECT
    product_name AS ProductName,
    list_price AS OriginalPrice,
    list_price + list_price * 0.05 AS NewPrice
FROM
    BikeStores.production.products
ORDER BY
    product_name ASC
    /* The Least Sold Products & The Most Expensive Ones */
SELECT
    TOP 10 order_items.product_id AS ProductID,
    quantity AS Quantity,
    products.product_name AS ProductName,
    products.list_price AS Price
FROM
    BikeStores.sales.order_items
    INNER JOIN BikeStores.production.products ON BikeStores.production.products.product_id = BikeStores.sales.order_items.product_id
WHERE
    products.list_price > 1000
ORDER BY
    order_items.quantity ASC
    /* The Customer with More Than 5 Orders */
SELECT
    TOP 10 COUNT(orders.customer_id) AS TotalOrdersPerCustomer,
    customers.first_name + ' ' + customers.last_name AS CustomerName
FROM
    BikeStores.sales.orders
    INNER JOIN BikeStores.sales.customers ON BikeStores.sales.customers.customer_id = BikeStores.sales.orders.customer_id
GROUP BY
    customers.first_name + ' ' + customers.last_name
ORDER BY
    COUNT(orders.customer_id) DESC
    /* The Most Profitable Store By Orders */
SELECT
    COUNT(orders.store_id) AS OrdersNumber,
    stores.store_name AS StoreName
FROM
    BikeStores.sales.orders
    INNER JOIN BikeStores.sales.stores ON BikeStores.sales.stores.store_id = BikeStores.sales.orders.store_id
GROUP BY
    stores.store_name
ORDER BY
    COUNT(orders.store_id) DESC
    /* The Most Profitable Store By Total Revenue */
SELECT
    SUM(order_items.list_price) AS TotalRevenue,
    stores.store_name AS StoreName
FROM
    BikeStores.sales.orders
    INNER JOIN BikeStores.sales.stores ON BikeStores.sales.stores.store_id = BikeStores.sales.orders.store_id
    INNER JOIN BikeStores.sales.order_items ON BikeStores.sales.order_items.order_id = BikeStores.sales.orders.order_id
GROUP BY
    stores.store_name
ORDER BY
    SUM(order_items.list_price) DESC
    /* Employees by Total Orders, Average Order Amount and Total Orders Amount */
SELECT
    COUNT(orders.staff_id) AS OrdersCount,
    staffs.first_name + ' ' + staffs.last_name as StaffMember
FROM
    BikeStores.sales.orders
    INNER JOIN BikeStores.sales.staffs ON BikeStores.sales.orders.staff_id = BikeStores.sales.staffs.staff_id FULL
    OUTER JOIN BikeStores.sales.stores ON BikeStores.sales.orders.store_id = BikeStores.sales.stores.store_id
GROUP BY
    staffs.first_name + ' ' + staffs.last_name
ORDER BY
    COUNT(orders.staff_id) DESC
    /* Employees by Average Order Amount and Total Orders Amount */
SELECT
    AVG(order_items.list_price) AS OrdersAverage,
    SUM(order_items.list_price) AS OrdersSum,
    staffs.first_name + ' ' + staffs.last_name as StaffMember
FROM
    BikeStores.sales.orders
    INNER JOIN BikeStores.sales.staffs ON BikeStores.sales.orders.staff_id = BikeStores.sales.staffs.staff_id
    INNER JOIN BikeStores.sales.order_items ON BikeStores.sales.orders.order_id = BikeStores.sales.order_items.order_id
GROUP BY
    staffs.first_name + ' ' + staffs.last_name
ORDER BY
    SUM(order_items.list_price) DESC
    /* The Days from the Order Until Today */
SELECT
    order_id as OrderID,
    order_date as OrderDate,
    DATEDIFF(DD, getdate(), order_date) AS DateFromOrder
FROM
    BikeStores.sales.orders