/*ALTER TABLE "Nikkei 225 Historical Data"
ADD COLUMN "Price (USD)" NUMERIC;*/

UPDATE "Nikkei 225 Historical Data" AS JPY
SET
	"Price (USD)" = ROUND(REPLACE(JPY."Price", ',', '')::NUMERIC * REPLACE(USD."Price", ',', '')::NUMERIC, 2)
FROM
	"Currency Converter USD JPY" AS USD
WHERE
	JPY."Date" = USD."Date";