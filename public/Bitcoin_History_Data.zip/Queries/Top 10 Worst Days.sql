SELECT
	"Date",
	ROUND("Open", 2) AS "Open",
	ROUND("Price", 2) AS "Price",
	ROUND("High" - "Low", 2) AS "Daily Range",
	ROUND(("High" / NULLIF("Low", 0)) - 1, 4) AS "Volatility Ratio",
	ROUND("Price" - "Open", 2) AS "Price Change",
	ROUND(("Price" - "Open") / NULLIF("Open", 0) * 100, 2) AS "% Change"
FROM
	"BTC_USD Bitfinex Historical Data"
ORDER BY
	"% Change" ASC
LIMIT
	10;