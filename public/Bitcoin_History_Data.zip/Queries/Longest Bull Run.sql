WITH
	Price_Diff AS (
		SELECT
			"Date",
			"Price",
			LAG("Price") OVER (
				ORDER BY
					"Date"
			) AS Prev_Price
		FROM
			"BTC_USD Bitfinex Historical Data"
	),
	Streaks AS (
		SELECT
			"Date",
			"Price",
			CASE
				WHEN "Price" > Prev_Price THEN 1
				ELSE 0
			END AS Up_Day
		FROM
			Price_Diff
	),
	Grouped_Streaks AS (
		SELECT
			"Date",
			Up_Day,
			SUM(
				CASE
					WHEN Up_Day = 0 THEN 1
					ELSE 0
				END
			) OVER (
				ORDER BY
					"Date" ROWS BETWEEN UNBOUNDED PRECEDING
					AND CURRENT ROW
			) AS GRP
		FROM
			Streaks
	)
SELECT
	COUNT(*) AS "Streak_Length",
	MIN("Date") AS "Streak_Start",
	MAX("Date") AS "Streak_End"
FROM
	Grouped_Streaks
WHERE
	up_day = 1
GROUP BY
	GRP
ORDER BY
	"Streak_Length" DESC
LIMIT
	10;