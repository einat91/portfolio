UPDATE "BTC_USD Bitfinex Historical Data"
SET
	"Date" = TO_DATE("Date", 'MM/DD/YYYY');