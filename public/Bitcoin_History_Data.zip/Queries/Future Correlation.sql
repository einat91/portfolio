WITH
	BTC_Volatility AS (
		SELECT
			DATE_TRUNC('Week', "Date")::DATE AS week,
			STDDEV("Price") AS Weekly_Volatility
		FROM
			"BTC_USD Bitfinex Historical Data"
		GROUP BY
			1
	),
	Trends_Weekly AS (
		SELECT
			DATE_TRUNC('Week', "Month_Date")::DATE AS week,
			AVG("Interest") AS AVG_Interest
		FROM
			"Google_Trends_Clean"
		GROUP BY
			1
	)
SELECT
	V.Week AS "Week",
	ROUND(
		CORR(V.Weekly_Volatility, T.AVG_Interest) OVER (
			ORDER BY
				V.Week ROWS BETWEEN 11 PRECEDING
				AND CURRENT ROW
		)::NUMERIC,
		6
	) AS "Rolling Correlation"
FROM
	BTC_Volatility V
	JOIN Trends_Weekly T ON V.Week = T.Week
ORDER BY
	V.Week;