SELECT
	TO_CHAR(DATE_TRUNC('Month', "Date"), 'Mon YYYY') AS "Month",
	ROUND(MAX("High") - MIN("Low"), 2) AS "Range",
	ROUND(((MAX("High") - MIN("Low")) / MIN("Low")) * 100, 2) AS "Range %"
FROM
	"BTC_USD Bitfinex Historical Data"
GROUP BY
	DATE_TRUNC('Month', "Date")
ORDER BY
	DATE_TRUNC('Month', "Date");