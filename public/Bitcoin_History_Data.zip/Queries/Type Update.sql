ALTER TABLE "BTC_USD Bitfinex Historical Data"
ALTER COLUMN "Date" TYPE DATE USING "Date"::DATE
ALTER COLUMN "Price" TYPE NUMERIC USING NULLIF(regexp_replace("Price", '[^0-9.]', '', 'g'), '')::NUMERIC
ALTER COLUMN "Open" TYPE NUMERIC USING NULLIF(regexp_replace("Open", '[^0-9.]', '', 'g'), '')::NUMERIC,
ALTER COLUMN "High" TYPE NUMERIC USING NULLIF(regexp_replace("High", '[^0-9.]', '', 'g'), '')::NUMERIC,
ALTER COLUMN "Low" TYPE NUMERIC USING NULLIF(regexp_replace("Low", '[^0-9.]', '', 'g'), '')::NUMERIC
ALTER COLUMN "Change %" TYPE NUMERIC USING NULLIF(regexp_replace("Change %", '[^0-9.-]', '', 'g'), '')::NUMERIC;