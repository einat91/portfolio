WITH
	Weekly_Prices AS (
		SELECT
			DATE_TRUNC('Week', "Date")::date AS "Week Start",
			FIRST_VALUE("Open") OVER (
				PARTITION BY
					DATE_TRUNC('Week', "Date")
				ORDER BY
					"Date"
			) AS Week_Open,
			LAST_VALUE("Price") OVER (
				PARTITION BY
					DATE_TRUNC('Week', "Date")
				ORDER BY
					"Date" ROWS BETWEEN UNBOUNDED PRECEDING
					AND UNBOUNDED FOLLOWING
			) AS Week_Close
		FROM
			"BTC_USD Bitfinex Historical Data"
	)
SELECT DISTINCT
	"Week Start",
	ROUND((Week_Close - Week_Open) / NULLIF(Week_Open, 0) * 100, 2) AS "Weekly % Change"
FROM
	Weekly_Prices
ORDER BY
	"Week Start" ASC;