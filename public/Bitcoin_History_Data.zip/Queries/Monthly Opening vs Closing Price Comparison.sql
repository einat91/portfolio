WITH
	Monthly_Bounds AS (
		SELECT
			DATE_TRUNC('Month', "Date") AS month_start,
			MIN("Date") AS First_Day,
			MAX("Date") AS Last_Day
		FROM
			"BTC_USD Bitfinex Historical Data"
		GROUP BY
			DATE_TRUNC('Month', "Date")
	),
	Monthly_Prices AS (
		SELECT
			B.Month_Start,
			O."Open" AS First_Open,
			C."Close" AS Last_Close
		FROM
			Monthly_Bounds B
			JOIN "BTC_USD Bitfinex Historical Data" O ON O."Date" = B.First_Day
			JOIN "Bitcoin_History_Data" C ON C."Date" = B.Last_Day
	)
SELECT
	TO_CHAR(Month_Start, 'Mon YYYY') AS "Month",
	ROUND(First_Open, 2) AS "First Open",
	ROUND(Last_Close, 2) AS "Last Close",
	CASE
		WHEN Last_Close > First_Open THEN 'Up'
		WHEN Last_Close < First_Open THEN 'Down'
		ELSE 'No Change'
	END AS "Trend"
FROM
	Monthly_Prices
ORDER BY
	Month_Start;